(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('listmembers', [
    'crmUi', 'crmUtil', 'ngRoute'
  ]);
})(angular, CRM.$, CRM._);
